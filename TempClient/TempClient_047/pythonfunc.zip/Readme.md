# Client

- Since this is just a simulation
- All clients are identical
- They pull the model from server
- return a random 2D array with same shape the pulled model (fake training)

# Functions 
##  Pull Model
- Simple calls getModel through get request
- unmarshall data
- checks size
- produces a new data of same size


